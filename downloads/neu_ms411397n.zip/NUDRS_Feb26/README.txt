Title: Knowledge gaps and areas for synthesis in experimental studies of context-dependent predation risk

Creator names: Nicole Peckham

Date created: 09-Feb-2026

Description: Datasets to support submitted manuscript to Ecology , titled "Knowledge gaps and areas for synthesis in experimental studies of context-dependent predation risk"

Keywords: context-dependence, ecology of fear, literature review, non-lethal, nonconsumptive effects, trait-mediated indirect effects, trait response

Full list of authors on paper: Peckham, Nicole; Northeastern University, Department of Marine and Environmental Science 
Peacor, Scott; Michigan State University, Fisheries and Wildlife 
Sheriff, Michael; University of Massachusetts Dartmouth, Department of Biology Smith, 
Justine; UC Davis, Wildlife, Fish, and Conservation Biology 
Dorn, Nathan; Florida International University 
Cherry, Michael; Texas A&M University Kingsville, Rangeland and Wildlife Sciences 
Rogers, Tanya; Southwest Fisheries Science Center, National Oceanic and Atmospheric Administration
Kimbro, David ; Northeastern University, Marine and Environmental Sciences